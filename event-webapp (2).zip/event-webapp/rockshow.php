				<?php include 'head.php';?>


				<hr>


				<!-- NAME OF THE SHOW -->

				<div class="row"><!-- name of event and menu links -->
					<div class="col-sm-3 blackbox">
						<p style="text-align: center">ROCK N ROLL SHOW</p>
					</div>
					<div class="col-sm-2 blackbox">
						<p style="text-align: center">7/9/2017</p>
					</div>
					<div class="col-sm-3 blackbox">
						<p style="text-align: center"><a href="rockshow.php">map and schedule</a></p>
					</div>
					<div class="col-sm-2 blackbox">
						<p style="text-align: center"><a href="posts.php">posts</a></p>
					</div>
					<div class="col-sm-2 blackbox">
						<p style="text-align: center">offers</p>
					</div>

				</div><!-- closes row name of the show -->


	<hr>

	<div class="row"><!-- map -->
		<div class="col-sm-12 blackbox maincolumn"><!-- main left column -->
			<img class="img-responsive center-block" src="images/country-thunder-map.png" alt="rocknroll">
		</div>

		</div><!-- closes pdf map -->


	<hr>


		<div class="row"><!-- schedule -->
			<div class="col-sm-12 blackbox maincolumn"><!-- main left column -->
					<img class="img-responsive center-block" src="images/schedule.png" alt="schedule">

			</div><!-- closes schedule -->


	</div><!-- closes schedule row -->



				<hr>

				<?php include 'footer.php';?>

<!-- container body and html divs close in footer-->
