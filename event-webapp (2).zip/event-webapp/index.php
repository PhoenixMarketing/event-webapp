
<?php include 'head.php';?>



<hr>

<!-- MAIN CONTENT -->


<?php include 'event-table.php';?>



<hr>

<?php include 'footer.php';?>



<!-- container body and html divs close in footer-->
