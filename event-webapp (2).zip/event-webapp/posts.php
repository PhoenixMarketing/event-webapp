<?php include 'head.php';?>


		<hr>

	<?php include 'rockshow-menu.php';?>

		<!-- NAME OF THE SHOW -->



		<hr>


		<div class="row"><!-- row1 -->

			<div class="col-sm-12 blackbox">
				<p>photo</p>
			</div><!--  -->


				<div class="col-sm-12 blackbox">
					<p>text</p>
				</div><!--  -->

			</div><!-- closes row1 -->


		<hr>


		<?php include 'footer.php';?>


	<!-- container body and html divs close in footer-->
