<?php include 'head.php';?>

			<hr>

			<!-- NAME OF THE SHOW -->

			<div class="row"><!-- name of event -->
				<div class="col-sm-12 blackbox">
					<h1>ME!</h1>
				</div>
			</div><!-- closes name of the show -->


			<hr>

			<div class="row"><!-- main outer row -->


				<!-- MAIN LEFT COLUMN -->

				<div class="col-sm-7 blackbox maincolumn"><!-- main left column -->
					<p>About Me</p>
				</div><!-- main left column -->






				<!-- MAIN RIGHT COLUMN -->

				<div class="col-sm-5 blackbox maincolumn"><!-- main right column -->
					<p>Special Offers</p>
				</div><!-- main right column -->


			</div><!-- main outer row -->



			<hr>

			<?php include 'footer.php';?>




			<!-- container body and html divs close in footer-->
