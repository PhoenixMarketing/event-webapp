
<!doctype html>
<html>



	<!-- BOTTOM MENU -->		

	<div class="row"><!-- bottom menu -->
		<div class="col-sm-3 blackbox">
			<h1><a href="index.php">home</a></h1>		
		</div>

		<div class="col-sm-3 blackbox">
			<h1><a href="me.php">me</a></h1>	
		</div>
		<div class="col-sm-3 blackbox">
			<h1>notifications</h1>		
		</div>
		<div class="col-sm-3 blackbox">
			<h1>extra</h1>		
		</div>

	</div><!-- closes bottom menu -->




</html>


